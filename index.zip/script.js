let athletes = [{    
    name: 'Jeff Hubbard',
    sex: 'Male',
    dob: '01/01/1980',
    nationality: 'USA'
}, {
    name: 'Mike Hubbard',
    sex: 'Male',
    dob: '01/01/1980',
    nationality: 'USA'
}, {
    name: 'Ross Hubbard',
    sex: 'Male',
    dob: '01/01/1980',
    nationality: 'USA'
}, {
    name: 'Pin Hubbard',
    sex: 'Male',
    dob: '01/01/1980',
    nationality: 'USA'
}];


$(document).ready(function() {
    console.log('ready');

    athletes.forEach(function(athlete) {
        console.log(athlete.name);
    })

    
    $("#about-section").click(function() {
        $('html, body').animate({
            scrollTop: 0
        }, 500);
    });

    $("#photos-section").click(function() {
        $('html, body').animate({
            scrollTop: $(".photo-grid").offset().top
        }, 500);
    });


});