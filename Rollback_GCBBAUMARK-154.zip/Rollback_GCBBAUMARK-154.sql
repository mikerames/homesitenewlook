-- ROLLBACK STEPS
-- Delete create filtervalues - 2 rows (CVA and DVA)
delete vlk_metric_filter
 where logicgroupid in
       (select logicgroupid
          from vlk_metric_logic_group
         where volckermetricid in
               (select volckermetricid
                  from vlk_volcker_metric m
                 where m.volckermetricname like
                       '%B4a_Comprehensive_Profit_and_Loss_CVA_Daily_and_DVA_Daily%'
                   and volckermetricid in
                       (select max(volckermetricid) from vlk_volcker_metric)));
commit;
/

-- Delete created logic group
delete vlk_metric_logic_group
 where volckermetricid in
       (select volckermetricid
          from vlk_volcker_metric m
         where m.volckermetricname like
               '%B4a_Comprehensive_Profit_and_Loss_CVA_Daily_and_DVA_Daily%'
           and volckermetricid in
               (select max(volckermetricid) from vlk_volcker_metric));
commit;
/

-- Delete created data for new metric in metric report
delete vlk_volcker_metric_report
 where volckermetricid in
       (select volckermetricid
          from vlk_volcker_metric m
         where m.volckermetricname like
               '%B4a_Comprehensive_Profit_and_Loss_CVA_Daily_and_DVA_Daily%'
           and volckermetricid in
               (select max(volckermetricid) from vlk_volcker_metric));
commit;
/


-- Delete new metric
delete vlk_volcker_metric m
 where m.volckermetricname like
       '%B4a_Comprehensive_Profit_and_Loss_CVA_Daily_and_DVA_Daily%'
   and volckermetricid in
       (select max(volckermetricid) from vlk_volcker_metric);
commit;
/

-- Remove the new metric reference from the main filter
update vlk_metric_filter mf
   set filtervalue = 'B4a_Comprehensive_Profit_and_Loss_Due_to_Changes_in_Risk_Factors + B4a_Comprehensive_Profit_and_Loss_Due_to_Actual_Cash_Flows + B4a_Comprehensive_Profit_and_Loss_Due_to_Carry + B4a_Comprehensive_Profit_and_Loss_Due_to_Reserve_or_Valuation_Adjustment_Changes + B4a_Comprehensive_Profit_and_Loss_Due_to_Trade_Changes + B4a_Profit_and_Loss_Other'
 where logicgroupid = 2
   and filtertypeid = 5;
commit;
/

