-- Create metric using procedure copy_metric using metric id 7 as reference
begin
  vlk_volcker_metrics_pkg.copy_metric(p_sourceMetricId => 1,
                                      p_targetSuffix   => '_CVA_Daily_and_DVA_Daily');
end;
/

-- Update the sequence number having the latest one as reference plus 10
update vlk_volcker_metric
   set sequencenumber =
       (select (select max(sequencenumber) + 10 from vlk_volcker_metric)
          from vlk_volcker_metric
         where volckermetricid in
               (select max(volckermetricid) from vlk_volcker_metric))
 where volckermetricid in
       (select max(volckermetricid) from vlk_volcker_metric);
commit;
/

-- Update the created logicgroupid to have the correct filtervalues 
-- which refer to pnl attribution ids - 389 and 341
-- CVA Daily - id 389
update vlk_metric_filter mf
   set filtervalue = 489
 where logicgroupid in
       (select lg.logicgroupid
          from vlk_metric_logic_group lg
         where lg.volckermetricid in
               (select max(volckermetricid) from vlk_volcker_metric))
   and filtertypeid = 1;
commit;
/

-- DVA Daily - id 341
update vlk_metric_filter mf
   set filtervalue = 491,
       filtertypeid = 1
 where logicgroupid in
       (select lg.logicgroupid
          from vlk_metric_logic_group lg
         where lg.volckermetricid in
               (select max(volckermetricid) from vlk_volcker_metric))
   and filtertypeid = 4;
commit;
/

-- Update the filter value used by Existing Positions to have the new metric
-- This is used to get the related values from vlk_volcker_metric_report by function REPLACE_METRICS
-- inside package vlk_volcker_metrics_pkg
update vlk_metric_filter mf
   set filtervalue = 'B4a_Comprehensive_Profit_and_Loss_Due_to_Changes_in_Risk_Factors + B4a_Comprehensive_Profit_and_Loss_Due_to_Actual_Cash_Flows + B4a_Comprehensive_Profit_and_Loss_Due_to_Carry + B4a_Comprehensive_Profit_and_Loss_Due_to_Reserve_or_Valuation_Adjustment_Changes + B4a_Comprehensive_Profit_and_Loss_Due_to_Trade_Changes + B4a_Profit_and_Loss_Other + B4a_Comprehensive_Profit_and_Loss_CVA_Daily_and_DVA_Daily'
 where logicgroupid = 2
   and filtertypeid = 5;
commit;
/
